class UsersController < ApplicationController
  def new
  end
end
