module ApplicationHelper
	#Views can use methods found in here, which is nice
end
